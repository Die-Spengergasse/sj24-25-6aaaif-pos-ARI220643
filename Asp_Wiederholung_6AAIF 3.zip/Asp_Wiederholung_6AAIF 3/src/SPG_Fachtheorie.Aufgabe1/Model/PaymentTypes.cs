﻿namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public enum PaymentType
    {  
        Cash,        // 0
        Maestro,     // 1
        CreditCard   // 2
    }
}