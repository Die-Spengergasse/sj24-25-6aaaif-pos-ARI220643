using Microsoft.EntityFrameworkCore;
using SPG_Fachtheorie.Aufgabe1.Infrastructure;
using SPG_Fachtheorie.Aufgabe1.Model;
using SPG_Fachtheorie.Aufgabe1.Services;
// using SPG_Fachtheorie.Aufgabe1.Commands; // Nicht benötigt, da Service keine Commands verwendet
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace SPG_Fachtheorie.Aufgabe1.Test
{
    [Collection("Sequential")]
    public class PaymentServiceTests
    {
        private AppointmentContext GetEmptyDbContext(string dbName = "cash_paymenttest.db") // Parameter für DB-Namen hinzugefügt
        {
            var options = new DbContextOptionsBuilder()
                .UseSqlite($"Data Source={dbName}") // Dynamischer DB-Name
                .Options;

            var db = new AppointmentContext(options);
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();
            return db;
        }

        // Hilfsmethode zum Seeden von Basisdaten
        private (CashDesk, Employee, Employee) SeedBasicData(AppointmentContext db)
        {
            var cashDesk = new CashDesk(1);
            var cashier = new Cashier(1001, "Max", "Mustermann", null, "Standard");
            var manager = new Manager(1002, "Maria", "Musterfrau", null, "Tesla");

            db.CashDesks.Add(cashDesk);
            db.Employees.AddRange(cashier, manager); // Fügt beide hinzu, EF erkennt Typen
            db.SaveChanges();
            db.ChangeTracker.Clear(); // Wichtig nach SaveChanges in Tests
            return (cashDesk, cashier, manager);
        }


        // --- Tests für CreatePayment ---

        [Theory]
        [InlineData(999, 1001, PaymentType.Cash, "CashDesk not found.")] // Ungültige Kassa
        [InlineData(1, 9999, PaymentType.Cash, "Employee not found.")] // Ungültiger Mitarbeiter
        [InlineData(1, 1001, PaymentType.CreditCard, "Insufficient rights")] // Kassierer darf keine Kreditkarte
        public void CreatePaymentExceptionsTest(int cashDeskNumber, int employeeRegNumber, PaymentType paymentType, string expectedErrorMessagePart)
        {
            // ARRANGE
            using var db = GetEmptyDbContext("CreatePaymentExceptionsTest.db");
            var (seededCashDesk, seededCashier, seededManager) = SeedBasicData(db);
            var paymentService = new PaymentService(db);

            // Hole Referenzen oder null basierend auf Testdaten
            var cashDesk = db.CashDesks.Find(cashDeskNumber);
            var employee = db.Employees.Find(employeeRegNumber);

            // ACT & ASSERT
            var ex = Assert.Throws<PaymentServiceException>(() => paymentService.CreatePayment(cashDesk!, employee!, paymentType));
            Assert.Contains(expectedErrorMessagePart, ex.Message);
        }

        [Fact]
        public void CreatePayment_OpenPaymentExists_ThrowsException()
        {
             // ARRANGE
            using var db = GetEmptyDbContext("CreatePayment_OpenPaymentExists.db");
            var (cashDesk, cashier, _) = SeedBasicData(db);
            var paymentService = new PaymentService(db);

            // Erstelle ein "offenes" Payment (PaymentDateTime = default)
            var openPayment = new Payment(cashDesk, default, cashier, PaymentType.Cash);
            db.Payments.Add(openPayment);
            db.SaveChanges();
            db.ChangeTracker.Clear();

             // ACT & ASSERT
            var ex = Assert.Throws<PaymentServiceException>(() => paymentService.CreatePayment(cashDesk, cashier, PaymentType.Maestro));
            Assert.Contains("Open payment for cashdesk", ex.Message);
        }


        [Theory]
        [InlineData(PaymentType.Cash)]
        [InlineData(PaymentType.Maestro)]
        public void CreatePaymentSuccessTest_Cashier(PaymentType paymentType)
        {
            // ARRANGE
            using var db = GetEmptyDbContext($"CreatePaymentSuccessTest_Cashier_{paymentType}.db");
            var (cashDesk, cashier, _) = SeedBasicData(db); // Manager nicht benötigt
            var paymentService = new PaymentService(db);

            // ACT
            var startTime = DateTime.UtcNow; // Zeit vor dem Aufruf
            var payment = paymentService.CreatePayment(cashDesk, cashier, paymentType);
            var endTime = DateTime.UtcNow; // Zeit nach dem Aufruf

            // ASSERT
            Assert.NotNull(payment);
            Assert.NotEqual(0, payment.Id); // ID sollte vergeben worden sein

            db.ChangeTracker.Clear();
            var paymentInDb = db.Payments
                                .Include(p => p.CashDesk)
                                .Include(p => p.Employee)
                                .SingleOrDefault(p => p.Id == payment.Id);

            Assert.NotNull(paymentInDb);
            Assert.Equal(cashDesk.Number, paymentInDb.CashDesk.Number);
            Assert.Equal(cashier.RegistrationNumber, paymentInDb.Employee.RegistrationNumber);
            Assert.Equal(paymentType, paymentInDb.PaymentType);
            Assert.NotEqual(default, paymentInDb.PaymentDateTime); // Sollte NICHT default sein nach Create
            Assert.True(paymentInDb.PaymentDateTime >= startTime && paymentInDb.PaymentDateTime <= endTime); // Prüft Zeitstempel Plausibilität
            Assert.Empty(paymentInDb.PaymentItems); // Initial keine Items
        }

        [Fact]
        public void CreatePaymentSuccessTest_Manager_CreditCard()
        {
             // ARRANGE
            using var db = GetEmptyDbContext("CreatePaymentSuccessTest_Manager_CreditCard.db");
            var (cashDesk, _, manager) = SeedBasicData(db); // Kassierer nicht benötigt
            var paymentService = new PaymentService(db);

            // ACT
            var payment = paymentService.CreatePayment(cashDesk, manager, PaymentType.CreditCard);

             // ASSERT
            Assert.NotNull(payment);
            db.ChangeTracker.Clear();
            var paymentInDb = db.Payments.Find(payment.Id);
            Assert.NotNull(paymentInDb);
            Assert.Equal(PaymentType.CreditCard, paymentInDb.PaymentType);
            Assert.Equal(manager.RegistrationNumber, paymentInDb.Employee.RegistrationNumber); // Lazy Loading oder Include nötig
        }


        // --- Tests für ConfirmPayment ---

        [Fact]
        public void ConfirmPayment_NotFound_ThrowsException()
        {
            // ARRANGE
            using var db = GetEmptyDbContext("ConfirmPayment_NotFound.db");
            var paymentService = new PaymentService(db);
            var nonExistentPaymentId = 999;

            // ACT & ASSERT
            var ex = Assert.Throws<PaymentServiceException>(() => paymentService.ConfirmPayment(nonExistentPaymentId));
            Assert.Contains("Payment not found", ex.Message);
        }

        [Fact]
        public void ConfirmPayment_AlreadyConfirmed_ThrowsException()
        {
             // ARRANGE
            using var db = GetEmptyDbContext("ConfirmPayment_AlreadyConfirmed.db");
            var (cashDesk, cashier, _) = SeedBasicData(db);
            var paymentService = new PaymentService(db);

            // Erstelle ein Payment und bestätige es direkt (implizit durch Service in CreatePayment)
            var payment = paymentService.CreatePayment(cashDesk, cashier, PaymentType.Cash);
             // Explizites Confirm ist nicht mehr nötig, da CreatePayment es schon setzt.
             // Wenn CreatePayment KEIN Datum setzen würde, wäre folgender Code nötig:
             // payment.PaymentDateTime = DateTime.UtcNow;
             // db.SaveChanges();
             // db.ChangeTracker.Clear();


             // ACT & ASSERT
             var ex = Assert.Throws<PaymentServiceException>(() => paymentService.ConfirmPayment(payment.Id));
             Assert.Contains("Payment already confirmed", ex.Message);
        }


        [Fact]
        public void ConfirmPaymentSuccessTest()
        {
            // ARRANGE
            // Da CreatePayment bereits das Datum setzt, müssen wir manuell ein Payment
            // mit default(DateTime) erstellen, um den unbestätigten Zustand zu simulieren.
            using var db = GetEmptyDbContext("ConfirmPaymentSuccessTest.db");
            var (cashDesk, cashier, _) = SeedBasicData(db);
            var paymentService = new PaymentService(db);

            var unconfirmedPayment = new Payment(cashDesk, default, cashier, PaymentType.Cash);
            db.Payments.Add(unconfirmedPayment);
            db.SaveChanges();
            var paymentId = unconfirmedPayment.Id;
            db.ChangeTracker.Clear();


            // ACT
            var confirmationTimeStart = DateTime.UtcNow;
            paymentService.ConfirmPayment(paymentId);
            var confirmationTimeEnd = DateTime.UtcNow;

            // ASSERT
            var paymentInDb = db.Payments.Find(paymentId);
            Assert.NotNull(paymentInDb);
            Assert.NotEqual(default(DateTime), paymentInDb.PaymentDateTime);
            Assert.True(paymentInDb.PaymentDateTime >= confirmationTimeStart && paymentInDb.PaymentDateTime <= confirmationTimeEnd);
        }


        // --- Tests für AddPaymentItem ---

        [Fact]
        public void AddPaymentItem_PaymentNotFound_ThrowsException()
        {
            // ARRANGE
            using var db = GetEmptyDbContext("AddPaymentItem_PaymentNotFound.db");
            var paymentService = new PaymentService(db);
            var nonExistentPaymentId = 999;

            // ACT & ASSERT
            var ex = Assert.Throws<PaymentServiceException>(() => paymentService.AddPaymentItem(nonExistentPaymentId, "Artikel", 1, 10));
            Assert.Contains("Payment not found", ex.Message);
        }

         [Fact]
        public void AddPaymentItem_PaymentAlreadyConfirmed_ThrowsException()
        {
            // ARRANGE
            using var db = GetEmptyDbContext("AddPaymentItem_PaymentConfirmed.db");
            var (cashDesk, cashier, _) = SeedBasicData(db);
            var paymentService = new PaymentService(db);
            var payment = paymentService.CreatePayment(cashDesk, cashier, PaymentType.Cash); // Dieses Payment hat bereits ein Datum
            var paymentId = payment.Id;
            db.ChangeTracker.Clear();


            // ACT & ASSERT
            var ex = Assert.Throws<PaymentServiceException>(() => paymentService.AddPaymentItem(paymentId, "Neuer Artikel", 1, 5));
            Assert.Contains("Payment already confirmed", ex.Message);
        }

        // Keine explizite Prüfung für ungültige Item-Daten im Service (z.B. negativer Preis)
        // Dies sollte ggf. im Model-Konstruktor oder durch DB-Constraints verhindert werden.


        [Fact]
        public void AddPaymentItemSuccessTest()
        {
            // ARRANGE
            using var db = GetEmptyDbContext("AddPaymentItemSuccess.db");
            var (cashDesk, cashier, _) = SeedBasicData(db);
            var paymentService = new PaymentService(db);

             // Erstelle manuell ein unbestätigtes Payment
            var payment = new Payment(cashDesk, default, cashier, PaymentType.Cash);
            db.Payments.Add(payment);
            db.SaveChanges();
            var paymentId = payment.Id;
            db.ChangeTracker.Clear();

            var articleName = "Test Artikel";
            var amount = 2;
            var price = 15.99m;

            // ACT
            paymentService.AddPaymentItem(paymentId, articleName, amount, price);

            // ASSERT
            db.ChangeTracker.Clear();
            var paymentInDb = db.Payments.Include(p => p.PaymentItems).SingleOrDefault(p => p.Id == paymentId);
            Assert.NotNull(paymentInDb);
            Assert.Single(paymentInDb.PaymentItems); // Nur ein Item hinzugefügt

            var itemInDb = paymentInDb.PaymentItems.First();
            Assert.Equal(articleName, itemInDb.ArticleName);
            Assert.Equal(amount, itemInDb.Amount);
            Assert.Equal(price, itemInDb.Price);
            Assert.Equal(paymentId, itemInDb.Payment.Id); // FK Check
        }

        // --- Tests für DeletePayment ---

         [Fact]
        public void DeletePayment_NotFound_ThrowsException()
        {
            // ARRANGE
            using var db = GetEmptyDbContext("DeletePayment_NotFound.db");
            var paymentService = new PaymentService(db);
            var nonExistentPaymentId = 999;

            // ACT & ASSERT
            // Annahme: deleteItems = false ist Standard oder muss explizit übergeben werden
            var ex = Assert.Throws<PaymentServiceException>(() => paymentService.DeletePayment(nonExistentPaymentId, false));
            Assert.Contains("Payment not found", ex.Message);
        }

        [Fact]
        public void DeletePayment_HasItems_DeleteItemsFalse_ThrowsException()
        {
             // ARRANGE
            using var db = GetEmptyDbContext("DeletePayment_HasItems_False.db");
            var (cashDesk, cashier, _) = SeedBasicData(db);
            var paymentService = new PaymentService(db);

            // Erstelle Payment mit Item
            var payment = new Payment(cashDesk, default, cashier, PaymentType.Cash);
            db.Payments.Add(payment);
            db.SaveChanges(); // Hol dir die ID
            var paymentId = payment.Id;
            var item = new PaymentItem("ToDelete", 1, 1, payment);
            db.PaymentItems.Add(item);
            db.SaveChanges();
            db.ChangeTracker.Clear();

             // ACT & ASSERT
            var ex = Assert.Throws<PaymentServiceException>(() => paymentService.DeletePayment(paymentId, false));
            Assert.Contains("Payment has items. Set deleteItems to true", ex.Message);

             // Verify payment still exists
             var paymentInDb = db.Payments.Find(paymentId);
             Assert.NotNull(paymentInDb);
        }


        [Fact]
        public void DeletePaymentSuccessTest_NoItems()
        {
             // ARRANGE
            using var db = GetEmptyDbContext("DeletePaymentSuccess_NoItems.db");
            var (cashDesk, cashier, _) = SeedBasicData(db);
            var paymentService = new PaymentService(db);

            // Erstelle Payment ohne Items
            var payment = new Payment(cashDesk, default, cashier, PaymentType.Cash);
            db.Payments.Add(payment);
            db.SaveChanges();
            var paymentId = payment.Id;
            db.ChangeTracker.Clear();

            // ACT
            paymentService.DeletePayment(paymentId, false); // deleteItems=false sollte hier ok sein

            // ASSERT
            var paymentInDb = db.Payments.Find(paymentId);
            Assert.Null(paymentInDb);
        }

        [Fact]
        public void DeletePaymentSuccessTest_WithItems_DeleteItemsTrue()
        {
             // ARRANGE
            using var db = GetEmptyDbContext("DeletePaymentSuccess_WithItems_True.db");
            var (cashDesk, cashier, _) = SeedBasicData(db);
            var paymentService = new PaymentService(db);

             // Erstelle Payment mit Item
            var payment = new Payment(cashDesk, default, cashier, PaymentType.Cash);
            db.Payments.Add(payment);
            db.SaveChanges(); // Hol dir die ID
            var paymentId = payment.Id;
            var item1 = new PaymentItem("Item1", 1, 10, payment);
            var item2 = new PaymentItem("Item2", 2, 5, payment);
            db.PaymentItems.AddRange(item1, item2);
            db.SaveChanges();
            var item1Id = item1.Id; // Merke Item IDs für Assert
            var item2Id = item2.Id;
            db.ChangeTracker.Clear();

            // ACT
            paymentService.DeletePayment(paymentId, true);

            // ASSERT
            var paymentInDb = db.Payments.Find(paymentId);
            Assert.Null(paymentInDb);

            var itemsInDb = db.PaymentItems.Where(i => i.Payment.Id == paymentId).ToList(); // Sollte nicht mehr funktionieren, da Payment weg ist
            Assert.Empty(itemsInDb);

            // Sicherer: Prüfe über IDs
            var item1InDb = db.PaymentItems.Find(item1Id);
            var item2InDb = db.PaymentItems.Find(item2Id);
            Assert.Null(item1InDb);
            Assert.Null(item2InDb);
        }
    }
} 